# ASCTool

1.新增重签名功能(可对未签名的apk进行签名) 
2.新增文件拖动功能
3.修复使用自定义签名报错问题

**打包文件在out目录下面**

---------2021年3月17日18:38:07更新--------


APk签名验证破解工具 APK Signature Crack Tool

本工具只对那些仅通过 PackageManager.getPackageInfo().signatures 来校验签名的应用有效。

基于JavaFx框架，使用Kotlin语言实现

## 软件界面

![](https://images.gitee.com/uploads/images/2019/0922/131337_2e0b8f07_5050769.png)

![](https://images.gitee.com/uploads/images/2019/0922/131337_755422d7_5050769.png)

## 下载

[码云下载](https://gitee.com/stars-one/ASCTool/raw/master/out/artifacts/ASCTool_jar/ASCTool.jar)

## 使用
### 1.安装jdk（jdk1.8+）
### 2.双击下载的ASCTool.jar,打开使用
