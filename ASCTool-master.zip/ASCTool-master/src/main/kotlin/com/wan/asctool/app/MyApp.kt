package com.wan.asctool.app

import com.wan.asctool.view.MainView
import tornadofx.App

class MyApp: App(MainView::class, Styles::class)