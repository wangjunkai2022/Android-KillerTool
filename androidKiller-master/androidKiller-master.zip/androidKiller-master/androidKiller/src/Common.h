#include <QString>



QString getFileContent(QString strFilePath);

QString getResPath(QString strResName);

QString getWorksSpacePath();

void setWorkSpacePath(QString strWorkSpacePath);

QString getAdbFilePath();

QString getAsFilePath();

QString getYeShengPath();

QString getYeShengAdb();

QString getYeShengExe();