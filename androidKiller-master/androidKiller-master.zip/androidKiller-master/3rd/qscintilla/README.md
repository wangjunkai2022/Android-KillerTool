# QScintilla

Fork of QScintilla for Sonic Pi experiments: https://riverbankcomputing.com/software/qscintilla/intro


Same license as https://www.riverbankcomputing.com/software/qscintilla/license
